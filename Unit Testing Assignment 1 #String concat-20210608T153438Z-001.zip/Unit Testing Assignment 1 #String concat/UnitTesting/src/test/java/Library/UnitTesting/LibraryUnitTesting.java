package Library.UnitTesting;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import org.testng.Assert;
import org.testng.annotations.*;

import Library.UnitTesting.library;

public class LibraryUnitTesting {
	
	library obj;
	String Result=" ";
	
	@BeforeClass
	public void init() {
		System.out.println("Before class");
			obj=new library();
	}
	
	
	@BeforeMethod
	public void ReintialisingResult()
	{
		System.out.println("Before Method");
		Result=" ";
	}
	
	@BeforeGroups("RegressionTest")
	public void initGroups()
	{
		System.out.println("Before Groups");
		obj=new library();
	}
	
	@BeforeGroups("SmokeTest")
	public void initBeforeSmoke() {
		obj = new library();
	}
	
	@Test(groups= {"RegressionTest"})
	public void concatenateTwoStringTesting() {
	
		Result = obj.concatenate("Aishwarya", "Vichare");
		
		Assert.assertEquals(Result,"Aishwarya Vichare","Concatenate doesnt work without both Strings");
	}
	
	@Test
	public void concatenateTwoIntegerTesting() {
	
		Result = obj.concatenate(10, 10);
		
		Assert.assertEquals(Result,"Not a string value");
	}
	
	@Test(groups= {"SmokeTest"})
	public void concatenateOneStringOneEmptyString() {
	
		Result = obj.concatenate("Aishwarya", " ");
		
		Assert.assertEquals(Result,"Aishwarya  ","Not a string value");
	}
	@Test(groups= {"RegressionTest"})
	public void concatenateOneStringOneNullString() {
	
		Result = obj.concatenate("Aishwarya", null);
		
		Assert.assertEquals(Result,"Aishwarya ","Not a string value");
	}
	
	@Test(groups= {"RegressionTest"})
	public void concatenateTwoNullString() {
	
		Result = obj.concatenate(null, null);
		
		Assert.assertEquals(Result,"Aishwarya ","Not a string value");
	}
	
	@Test(dataProvider = "provideStrings")
	public void testConcatenationUsingDataDriven(String name, String surname, String result) {
		Result = obj.concatenate(name, surname);
		Assert.assertEquals(Result, result);
	}
	

	@DataProvider
	public Object[][] provideStrings() {
		Object[][] FullName = { 
				{ "Aishwarya", "Vichare", "Aishwarya Vichare" }, 
				{ "Arya", "Vichare", "Arya Vichare" },
				{ "Abhidnya", "Bhave", "Abhidnya Bhave" }
		};
		return FullName;
	}
	

	@AfterMethod
	public void clearResult() {
		System.out.println("After Mehtod");
		Result = "";
	}

	@AfterClass
	public void tearDown() {
		obj = null;
	}
	
	@BeforeSuite
	@Parameters({"RequestID"})

	public void createResultFolder(String ResultDir) {
		System.out.println("I am in before Suite");
		try
		{
		Files.createDirectories(Paths.get("./"+ResultDir));
		}
		catch (IOException e)
		{
			System.out.println("Problem in creating a Result Directory");
		}
		
	}

	@Parameters({"RequestID"})
	@AfterSuite

	public void copyResultFile(String RequestID) throws Exception{
		System.out.println("I am in after Suite");
		try {
			Files.copy(Paths.get("C:\\Users\\lenovo\\eclipse-workspace\\UnitTesting\\test-output\\emailable-report.html"), Paths.get("./"+RequestID+"/Result.html"),StandardCopyOption.REPLACE_EXISTING);	} catch (IOException e) {
			// TODO Auto-generated catch block
				System.out.println("Problem in copying Result file");
		}
	}

	}


