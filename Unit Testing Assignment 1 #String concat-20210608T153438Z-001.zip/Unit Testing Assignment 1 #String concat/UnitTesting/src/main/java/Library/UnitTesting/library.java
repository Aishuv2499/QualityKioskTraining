package Library.UnitTesting;

public class library {
	
	
	public String concatenate(String name, String surname)
	{
		String fullName= name+" "+surname;

		return fullName;
	}

}
